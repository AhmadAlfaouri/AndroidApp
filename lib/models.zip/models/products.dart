class Product {
  final name;
  final price;

  Product({this.name, this.price});
}
